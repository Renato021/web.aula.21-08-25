const form = document.getElementById("produtoForm");
const lista = document.getElementById("listaProdutos");
const categoriaSelect = document.getElementById("categoriaSelect");

// Converte imagem em Base64
function converterImagemBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

// Carrega categorias no <select>
async function carregarCategorias() {
  const res = await fetch("/api/categorias");
  const categorias = await res.json();

  categoriaSelect.innerHTML = '<option value="">Selecione a categoria</option>';

  categorias.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c.nome;
    opt.textContent = c.nome;
    categoriaSelect.appendChild(opt);
  });
}

// Carrega produtos
async function carregarProdutos() {
  const res = await fetch("/api/produtos");
  const produtos = await res.json();
  lista.innerHTML = "";

  produtos.forEach((p) => {
    const div = document.createElement("div");
    div.classList.add("card");

    div.innerHTML = `
      <h3>${p.nome}</h3>
      <p><strong>R$ ${parseFloat(p.preco).toFixed(2).replace('.', ',')}</strong></p>
      <p><strong>Categoria:</strong> ${p.categoria}</p>
      <p>${p.descricao}</p>
      ${
        p.imagem
          ? `<img src="${p.imagem}" alt="${p.nome}" style="width:200px; border-radius:10px;">`
          : "<p><em>Sem imagem</em></p>"
      }
      <button onclick="excluirProduto(${p.id})">Excluir</button>
    `;

    lista.appendChild(div);
  });
}

// Salva novo produto
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const imagemArquivo = document.getElementById("imagem").files[0];
  let imagemBase64 = "";

  if (imagemArquivo) {
    imagemBase64 = await converterImagemBase64(imagemArquivo);
  }

  const novoProduto = {
    nome: document.getElementById("nome").value,
    preco: document.getElementById("preco").value,
    descricao: document.getElementById("descricao").value,
    categoria: categoriaSelect.value,
    imagem: imagemBase64
  };

  await fetch("/api/produtos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(novoProduto)
  });

  form.reset();
  carregarProdutos();
});

// Excluir produto
async function excluirProduto(id) {
  await fetch(`/api/produtos/${id}`, { method: "DELETE" });
  carregarProdutos();
}

// Inicialização
carregarCategorias();
carregarProdutos();
