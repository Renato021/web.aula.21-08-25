const apiCategorias = "/api/categorias";

const lista = document.getElementById("listaCategorias");
const form = document.getElementById("categoriaForm");

// Carregar categorias
async function carregarCategorias() {
  const res = await fetch(apiCategorias);
  const categorias = await res.json();

  lista.innerHTML = "";

  categorias.forEach((c) => {
    const div = document.createElement("div");
    div.classList.add("card");

    div.innerHTML = `
      <h3>${c.nome}</h3>
      <button onclick="excluir(${c.id})">Excluir</button>
    `;

    lista.appendChild(div);
  });
}

// Adicionar nova categoria
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const novaCategoria = {
    nome: document.getElementById("nome").value
  };

  await fetch(apiCategorias, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(novaCategoria)
  });

  form.reset();
  carregarCategorias();
});

// Excluir categoria
async function excluir(id) {
  if (confirm("Deseja excluir esta categoria?")) {
    await fetch(`${apiCategorias}/${id}`, { method: "DELETE" });
    carregarCategorias();
  }
}

// Inicializar
carregarCategorias();
